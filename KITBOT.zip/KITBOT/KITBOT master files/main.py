# Start of the application
import modules.security